# JS Image Slider - make the buttons do something!

A Pen created on CodePen.io. Original URL: [https://codepen.io/alvarotrigo/pen/abyYVoP](https://codepen.io/alvarotrigo/pen/abyYVoP).

